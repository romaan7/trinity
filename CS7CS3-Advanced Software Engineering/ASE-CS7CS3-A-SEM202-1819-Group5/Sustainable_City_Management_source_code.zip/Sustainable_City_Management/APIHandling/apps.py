from django.apps import AppConfig


class ApiHandlingConfig(AppConfig):
    name = 'APIHandling'
