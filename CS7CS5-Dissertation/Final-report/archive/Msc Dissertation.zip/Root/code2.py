
#Impute the missing values using IterativeImputer from sklearn
MAX_ITER = 10
imp = SimpleImputer(missing_values=np.nan, strategy='mean')
imp = IterativeImputer(max_iter=MAX_ITER,initial_strategy='knn', random_state=0)
	imputed_DF = pd.DataFrame(imp.fit_transform(main_frame))
    imputed_DF.columns = required_columns_df.columns
    imputed_DF.index = required_columns_df.index
