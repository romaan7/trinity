from django.contrib import admin
from .models import BusLuas

# Register your models here.
admin.site.register(BusLuas)

