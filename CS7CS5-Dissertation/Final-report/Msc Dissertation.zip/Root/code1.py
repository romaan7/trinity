#Load projects data from csv
projects_df = pd.read_csv('data/CSVs/project_blocks.csv', sep=',',index_col=0,)

#Imputing the others data since it has mostly the null values.
projects_df = projects_df.drop(columns="other")
#Load projects_sprites data from csv
project_sprites_df = pd.read_csv('data/CSVs/project_sprites.csv', sep=',',index_col=0)

#Merge both the panda dataframes on project_id
main_frame = pd.merge(projects_df, galleries_df, left_index=True, right_index=True)