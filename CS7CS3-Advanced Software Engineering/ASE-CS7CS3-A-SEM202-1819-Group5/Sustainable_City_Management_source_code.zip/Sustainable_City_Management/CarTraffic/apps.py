from django.apps import AppConfig


class CarTrafficConfig(AppConfig):
    name = 'CarTraffic'
