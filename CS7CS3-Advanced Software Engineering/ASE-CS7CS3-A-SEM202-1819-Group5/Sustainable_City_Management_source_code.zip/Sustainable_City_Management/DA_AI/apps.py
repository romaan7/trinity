from django.apps import AppConfig


class DaAiConfig(AppConfig):
    name = 'DA_AI'
