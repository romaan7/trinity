from django.apps import AppConfig


class CityeventsConfig(AppConfig):
    name = 'CityEvents'
