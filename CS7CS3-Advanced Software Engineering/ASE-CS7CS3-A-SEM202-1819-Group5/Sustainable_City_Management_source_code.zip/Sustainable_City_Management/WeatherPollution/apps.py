from django.apps import AppConfig


class WeatherpollutionConfig(AppConfig):
    name = 'WeatherPollution'
