#Get Top 5 from the similarity matrix
top5 = final_df.loc[project_id].nlargest(5)
recommendation_pairs = top5.to_dict()
