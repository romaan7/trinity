from django.apps import AppConfig


class BikeConfig(AppConfig):
    name = 'Bike'
