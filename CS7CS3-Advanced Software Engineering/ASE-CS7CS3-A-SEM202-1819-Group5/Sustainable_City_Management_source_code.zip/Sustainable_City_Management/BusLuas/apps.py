from django.apps import AppConfig


class BusLuasConfig(AppConfig):
    name = 'BusLuas'
