#Calculates the prediction score for a user given recommendation as the list of similar recommended projects and target project_id
def calculate_prediction_score(user_id,project_id,similar_recommendation):
	_w = [get_user_ratings(user_id)]
	_x = similar_recommendation
	score = sum( _x * _w for _x, _w in zip( x, w ) )/ calculate_score(_x)
	return score 
